package com.capgemini.wsb.Service.Impl;

import com.capgemini.wsb.dto.VisitTO;
import com.capgemini.wsb.mapper.VisitMapper;
import com.capgemini.wsb.persistence.dao.VisitDao;
import com.capgemini.wsb.persistence.entity.VisitEntity;
import com.capgemini.wsb.service.impl.PatientServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
//Działą
class PatientServiceImplFindVisitsByIdTest {

    @Mock
    private VisitDao visitDao;

    @InjectMocks
    private PatientServiceImpl patientService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindVisitsByPatientId() {
        Long patientId = 1L;

        VisitEntity visitEntity1 = new VisitEntity();
        visitEntity1.setId(1L);
        visitEntity1.setId(patientId);

        VisitEntity visitEntity2 = new VisitEntity();
        visitEntity2.setId(2L);
        visitEntity2.setId(patientId);

        List<VisitEntity> visitEntities = Arrays.asList(visitEntity1, visitEntity2);

        when(visitDao.findVisitsByPatientId(patientId)).thenReturn(visitEntities);

        List<VisitTO> expectedVisits = visitEntities.stream()
                .map(VisitMapper::mapToTO)
                .collect(Collectors.toList());

        List<VisitTO> actualVisits = patientService.findVisitsByPatientId(patientId);

        // Assert that the size of the lists are equal
        assertEquals(expectedVisits.size(), actualVisits.size());

        // Assert that the content of the lists are equal
        for (int i = 0; i < expectedVisits.size(); i++) {
            assertEquals(expectedVisits.get(i).getId(), actualVisits.get(i).getId());
            assertEquals(expectedVisits.get(i).getId(), actualVisits.get(i).getId());
        }
    }
}

package com.capgemini.wsb.persistance.dao;

import com.capgemini.wsb.persistence.dao.PatientDao;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

//Działa
@RunWith(SpringRunner.class)
@SpringBootTest
public class PatientDaoImplFindPatientsWithMoreThanXVisitsTest {

    @Autowired
    private PatientDao patientDao;

    @Transactional
    @Test
    public void testShouldFindPatientsWithMoreThanXVisits() {
        // given
        int number_of_visits = 0;
        // when
        List<PatientEntity> patients = patientDao.findPatientsWithMoreThanXVisits(number_of_visits);
        // then
        assertThat(patients).isNotNull();
        assertThat(patients).hasSizeGreaterThan(0);
        for (PatientEntity patient : patients) {
            assertThat(patient.getVisits()).hasSizeGreaterThan(number_of_visits);
        }
    }
}

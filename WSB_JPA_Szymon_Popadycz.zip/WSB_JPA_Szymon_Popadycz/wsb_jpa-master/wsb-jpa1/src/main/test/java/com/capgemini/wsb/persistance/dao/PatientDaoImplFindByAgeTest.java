package com.capgemini.wsb.persistance.dao;

import com.capgemini.wsb.persistence.entity.PatientEntity;
import com.capgemini.wsb.persistence.dao.PatientDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;

//Działą
@RunWith(SpringRunner.class)
@SpringBootTest
public class PatientDaoImplFindByAgeTest {

    @Autowired
    private PatientDao patientDao;

    @Transactional
    @Test
    public void testFindByAge() {
        // given
        int ageToFind = 30;

        // when
        List<PatientEntity> patients = patientDao.findByAge(ageToFind);

        // then
        assertThat(patients).isNotNull();
        assertThat(patients.size()).isGreaterThan(0);
        for (PatientEntity patient : patients) {
            assertThat(patient.getAge()).isEqualTo(ageToFind);
        }
    }
}
